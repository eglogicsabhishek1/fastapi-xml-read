import xml.etree.ElementTree as ET
from faker import Faker
import random
from uuid import uuid4
from datetime import datetime, timedelta

# Initialize Faker
fake = Faker()

def create_fake_job():
    job = ET.Element("job")

    # Generate a random GUID
    guid = str(uuid4().int >> 64)

    # Generate job URL
    url = f"https://ch.jooble.org/external/{guid}?cpc=d0FVdlZFWw%3D%3D&utm_source=affiliate"

    # Generate fake job title
    title = f"{fake.job()} ({random.choice(['m/w/d', 'f/m/d', 'm/f/d'])})"

    # Generate fake company name
    company = fake.company()

    # Generate fake city and state
    city = fake.city()
    state = f"{city}, {fake.state_abbr()}, {fake.state()}"

    # Generate current date for date_updated
    date_updated = datetime.now().strftime("%Y-%m-%d 00:00:00")

    # Generate CPC (cost per click)
    cpc = round(random.uniform(0.05, 0.15), 5)

    # Salary data
    salary_min = random.randint(1, 100)
    salary_max = random.randint(101, 201)

    # Description
    description = f"{company} is currently hiring for positions such as:\n<h2>{title}</h2>\n<p>Location: {city} / Part-time / Flexible</p>"

    # Build the job XML
    def sub_elem(parent, tag, text=""):
        e = ET.SubElement(parent, tag)
        e.text = text
        return e    

    # Add elements to the job XML
    sub_elem(job, "guid", guid)
    sub_elem(job, "referencenumber", guid)
    sub_elem(job, "url", url)
    sub_elem(job, "title", title)

    region = ET.SubElement(job, "region")
    sub_elem(region, "country", "CH")
    sub_elem(region, "state", state)
    sub_elem(region, "city", city)

    sub_elem(job, "date_updated", date_updated)
    sub_elem(job, "cpc", str(cpc))
    sub_elem(job, "currency", "USD")
    sub_elem(job, "company", company)

    # Generate a random expiration date (e.g., 30-60 days from today)
    date_expired = (datetime.now() + timedelta(days=random.randint(30, 60))).strftime("%Y-%m-%d 00:00:00")
    sub_elem(job, "date_expired", date_expired)

    # Random job type selection
    job_types = ["Full-time", "Part-time", "Freelance", "Internship", "Contract"]
    jobtype = random.choice(job_types)
    sub_elem(job, "jobtype", jobtype)

    # Add salary info (make sure these values are added under the 'salary' element)
    salary = ET.SubElement(job, "salary")
    sub_elem(salary, "min", str(salary_min))
    sub_elem(salary, "max", str(salary_max))
    sub_elem(salary, "currency", "USD")
    sub_elem(salary, "rate", "annual")

    sub_elem(job, "description", description)

    return job

def main():
    # Number of jobs to generate
    num_jobs = 1

    jobs_root = ET.Element("jobs")
    for _ in range(num_jobs):
        jobs_root.append(create_fake_job())

    tree = ET.ElementTree(jobs_root)
    ET.indent(tree, space="    ", level=0)

    # Dynamic file name with timestamp
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = f"jobs_{timestamp}.xml"

    # Write to file
    with open(filename, "w", encoding="utf-8") as f:
        f.write(ET.tostring(jobs_root, encoding="utf-8", xml_declaration=True).decode("utf-8"))

    print(f"XML file '{filename}' created successfully with {num_jobs} job(s).")

if __name__ == "__main__":
    main()
