from sqlalchemy import Column, Integer, String, Float, DateTime
from sqlalchemy.orm import relationship
from app.database import Base

class Job(Base):
    __tablename__ = 'jobs'

    id = Column(Integer, primary_key=True, index=True)
    guid = Column(String(255), unique=True, index=True)  
    reference = Column(String(255), nullable=True)  
    url = Column(String(255), nullable=True) 
    title = Column(String(255), nullable=True)  
    country = Column(String(100), nullable=True) 
    state = Column(String(100), nullable=True)  
    city = Column(String(100), nullable=True)  
    date_updated = Column(DateTime, nullable=True)
    cpc = Column(Float, nullable=True) 
    currency = Column(String(10), nullable=True)  
    company = Column(String(255), nullable=True) 
    date_expired = Column(DateTime, nullable=True)  
    jobtype = Column(String(50), nullable=True) 
    salary_min = Column(Float, nullable=True)  
    salary_max = Column(Float, nullable=True)  
    salary_currency = Column(String(10), nullable=True)  
    salary_rate = Column(String(50), nullable=True)  
    description = Column(String(1000), nullable=True) 

    def __repr__(self):
        return f"<Job(title={self.title}, company={self.company}, salary_min={self.salary_min})>"

