import xml.sax

def parse_xml(file_path, handler):
    parser = xml.sax.make_parser()
    parser.setContentHandler(handler)
    parser.parse(file_path)
