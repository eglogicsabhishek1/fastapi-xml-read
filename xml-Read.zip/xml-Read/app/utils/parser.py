from xml.sax.handler import ContentHandler
from datetime import datetime

class JobHandler(ContentHandler):
    def __init__(self):
        self.jobs = []
        self.current_data = {}
        self.current_tag = ""
        self.buffer = ""

    def startElement(self, tag, attrs):
        self.current_tag = tag
        if tag == "job":
            self.current_data = {}
    
    def characters(self, content):
        if self.current_tag:
            self.buffer += content

    def endElement(self, tag):
        if tag == "job":
            self.jobs.append(self.current_data)
        elif self.current_tag:
            self.current_data[self.current_tag] = self.buffer.strip()
        self.buffer = ""
        self.current_tag = ""
 