from app.models import Job
from sqlalchemy.orm import Session
from typing import List
import datetime
import xmltodict

FIELD_MAP = {
    'guid': 'guid',
    'referencenumber': 'reference',
    'url': 'url',
    'title': 'title',
    'country': 'country',
    'state': 'state',
    'city': 'city',
    'date_updated': 'date_updated',
    'cpc': 'cpc',
    'currency': 'currency',
    'company': 'company',
    'date_expired': 'date_expired',
    'jobtype': 'jobtype',
    'salary_min': 'salary_min',
    'salary_max': 'salary_max',
    'salary_currency': 'salary_currency',
    'salary_rate': 'salary_rate',
    'description': 'description'
}

def parse_salary(salary_data):
    """
    Parses the salary fields (min, max, currency, rate) and returns a dictionary.
    """
    try:
        salary = {
            "salary_min": float(salary_data.get('min', 0)) if salary_data.get('min') else None,
            "salary_max": float(salary_data.get('max', 0)) if salary_data.get('max') else None,
            "salary_currency": salary_data.get('currency', None),
            "salary_rate": salary_data.get('rate', None)
        }
        return salary
    except ValueError:
        return {"salary_min": None, "salary_max": None, "salary_currency": None, "salary_rate": None}


def try_parse_datetime(value):
    """
    Tries to parse a datetime value from a string, returning None if it fails.
    """
    if value:
        try:
            return datetime.datetime.strptime(value, "%Y-%m-%d %H:%M:%S") 
        except ValueError:
            return None
    return None

def map_fields(xml_dict):
    """
    Maps the XML data fields to match the SQLAlchemy model field names.
    Ensures salary fields and dates are properly parsed.
    """
    mapped_data = {}
    for k, v in xml_dict.items():
        # If the field is in the FIELD_MAP, map it
        if k in FIELD_MAP:
            mapped_data[FIELD_MAP[k]] = v
    
    # Handle salary fields with a helper function to ensure valid numbers or None
    salary_data = parse_salary(xml_dict.get("salary", {}))
    mapped_data.update(salary_data)
    
    # Parse region data (country, state, city)
    if 'region' in xml_dict:
        region = xml_dict['region']
        mapped_data['country'] = region.get('country', None)
        mapped_data['state'] = region.get('state', None)
        mapped_data['city'] = region.get('city', None)
    
    # Parse date fields
    mapped_data["date_updated"] = try_parse_datetime(mapped_data.get("date_updated"))
    mapped_data["date_expired"] = try_parse_datetime(mapped_data.get("date_expired"))

    return mapped_data

def upsert_jobs_in_batches(jobs_data: List[dict], db: Session, batch_size=100):
    inserted_count = 0
    updated_count = 0

    for i in range(0, len(jobs_data), batch_size):
        batch = jobs_data[i:i + batch_size]

        for job_data in batch:
            job_data = map_fields(job_data)
            job_data["guid"] = job_data["guid"].strip()  

            existing_job = db.query(Job).filter(Job.guid == job_data["guid"]).first()

            if existing_job:
                for key, value in job_data.items():
                    if value is not None:
                        setattr(existing_job, key, value)
                updated_count += 1
            else:
                new_job = Job(**job_data)
                db.add(new_job)
                inserted_count += 1

        db.commit() 

    return inserted_count, updated_count
      
      