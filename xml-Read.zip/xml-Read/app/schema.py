from pydantic import BaseModel
from typing import Optional
from datetime import datetime

class JobCreate(BaseModel):
    guid: str
    reference: Optional[str]
    url: Optional[str]
    title: Optional[str]
    country: Optional[str]
    state: Optional[str]
    city: Optional[str]
    date_updated: Optional[datetime]
    cpc: Optional[str]
    currency: Optional[str]
    company: Optional[str]
    date_expired: Optional[datetime]
    jobtype: Optional[str]
    salary_min: Optional[float]
    salary_max: Optional[float]
    salary_currency: Optional[str]
    salary_rate: Optional[str]
    description: Optional[str]

class JobResponse(JobCreate):
    id: int

    class Config:
        orm_mode = True
