from fastapi import FastAPI
from app.routes.job_routes import router as job_router
from app.database import Base, engine

Base.metadata.create_all(bind=engine)

app = FastAPI(
    title="XML Job Ingestion API",
    description="Upload XML and ingest into MySQL",
    version="1.0.0"
)

app.include_router(job_router, prefix="/api")
